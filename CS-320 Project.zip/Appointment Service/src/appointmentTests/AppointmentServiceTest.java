package appointmentTests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import appointmentService.Appointment;
import appointmentService.AppointmentService;

class AppointmentServiceTest {

	@Test
	void addAppointmentServiceTest() {
		AppointmentService Appoint = new AppointmentService();
		Appointment Appoint1 = new Appointment("001", new Date(), "Testing First Appointment");
		Appointment Appoint2 = new Appointment("002", new Date(), "Testing Second Appointment");
		Appointment Appoint3 = new Appointment("001", new Date(), "Testing Third Appointment");
		Appointment Appoint4 = new Appointment("004", new Date(), "Testing Fourth Appointment");
		assertEquals(true, Appoint.add(Appoint1));
		assertEquals(true, Appoint.add(Appoint2));
		assertEquals(false, Appoint.add(Appoint3));
		assertEquals(true, Appoint.add(Appoint4));
	}
	
	@Test
	void deleteAppointmentServiceTest() {
		AppointmentService Appoint = new AppointmentService();
		Appointment Appoint1 = new Appointment("001", new Date(), "Testing First Appointment");
		Appointment Appoint2 = new Appointment("002", new Date(), "Testing Second Appointment");
		assertEquals(true, Appoint.add(Appoint1));
		assertEquals(true, Appoint.add(Appoint2));
		assertEquals(true, Appoint.remove("001"));
		assertEquals(false, Appoint.remove("004"));
		assertEquals(true, Appoint.remove("002"));
	}

}
