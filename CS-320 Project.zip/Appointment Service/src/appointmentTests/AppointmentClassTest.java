package appointmentTests;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import appointmentService.Appointment;



class AppointmentClassTest {

	// Test to create new Appointment to see if it's true
		@Test
		void testAppointment() {
			Date date1;
			Appointment appointment = new Appointment("0001",date1 = new Date() , "This is the first Appointment");
			assertTrue(appointment.getAppointmentID().equals("0001"));
			assertTrue(appointment.getAppointmentDate().equals(date1));
			assertTrue(appointment.getAppointmentDescription().equals("This is the first Appointment"));
		}
		
		// Test to see when Appointment ID length over 10 throws exception
		@Test
		void testAppointmentIDToLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("123456789123", new Date(), "This is the first Appointment");
			}); 
		}
		
		// Test to see when Appointment ID is null if exception is thrown
		@Test
		void testAppointmentIDisNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment(null, new Date(), "This is the first Appointment");
			}); 
		}
		
		// Test to see when Appointment Date is in the past exception is thrown
		@Test
		void testAppointmentDatePast() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("0001", new Date(-1), "This is the first Appointment");
			}); 
		}
		
		// Test to see when Appointment Date is null exception is thrown
		@Test
		void testAppointmentDateNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("0001", null, "This is the first Appointment");
			}); 
		}
		
		// Test to see when Appointment description is over 50 exception is thrown
		@Test
		void testAppointmentDescriptionToLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("0001", new Date(), "This Description is to long This Description is to long");
			}); 
		}
		
		// Test to see when A description is null, if exception is thrown
		@Test
		void testAppointmentDescriptionNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("0001", new Date(), null);
			}); 
		}
	}
