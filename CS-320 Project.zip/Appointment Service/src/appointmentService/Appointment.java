package appointmentService;

import java.util.Date;

public class Appointment {
	
	private String appointmentID;
	private Date appointmentDate;
	private String appointmentDescription;
	

	
	// If Statements
	public Appointment(String appointmentID, Date appointmentDate, String appointmentDescription) {
		if (appointmentID == null || appointmentID.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if (appointmentDate == null || new Date().after(appointmentDate)) {
			throw new IllegalArgumentException("Invalid Date");
		}
		if (appointmentDescription == null || appointmentDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		this.appointmentID = appointmentID;
		this.appointmentDate = appointmentDate;
		this.appointmentDescription = appointmentDescription;
	}
	
	// Setters and Getters
	public void setAppointmentID(String appointmentID) {
		this.appointmentID = appointmentID;
	}
	
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public void setAppointmentDescription(String appointmentDescription) {
		this.appointmentDescription = appointmentDescription;
	}
	
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
}
