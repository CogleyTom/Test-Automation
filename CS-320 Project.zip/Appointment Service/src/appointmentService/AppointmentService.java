package appointmentService;

import java.util.ArrayList;

public class AppointmentService {
	
	private ArrayList<Appointment>appointments;
	
	// Create Array List
	public AppointmentService() {
		appointments = new ArrayList<>();
	}
	
	// Add appointment if there is no appointment with same ID
	public boolean add(Appointment appointment) {
		boolean exists = false;
		for (Appointment A : appointments) {
			if (A.getAppointmentID().equals(appointment.getAppointmentID())) {
				exists = true;
			}
		}
		if (!exists) {
			appointments.add(appointment);
			System.out.println("Appointment Added");
			return true;
		} else {
			System.out.println("Appointment already in System");
			return false;
		}
	}
	
	// Delete appointment based on appointment ID
	public boolean remove(String appointmentID) {
		for (Appointment A : appointments) {
			if (A.getAppointmentID().equals(appointmentID)) {
				appointments.remove(A);
				System.out.println("Appointment Successfully Removed");
				return true;
			}
		}
		System.out.println("Appointment Does not exist");
		return false;
	}
}
