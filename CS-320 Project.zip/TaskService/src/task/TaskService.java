package task;

import java.util.ArrayList;

public class TaskService {
	
	private ArrayList<Task>tasks;
	
	// Create Array List
	public TaskService() {
		tasks = new ArrayList<>();
	}
	
	// Add Task Service if a new task ID is presented
	public boolean add(Task task) {
		boolean exists = false;
		for (Task T : tasks) {
			if (T.getTaskID().equals(task.getTaskID())) {
				exists = true;
			}
		}
		if (!exists) {
			tasks.add(task);
			System.out.println("Task Added");
			return true;
		}
		else {
			System.out.println("Task ID Already Exists");
			return false;
		}
	}
	
	// Remove Task Service if inputed Task ID matches one in array
	public boolean remove(String taskID) {
		for (Task T : tasks) {
			if (T.getTaskID().equals(taskID)) {
				tasks.remove(T);
				System.out.println("Task Service Removed Successfully");
				return true;
			}
		}
		System.out.println("Task Service does not exist");
		return false;
	}
	
	// Updates Task Service if conditions are met
	public boolean update(String taskID, String taskName, String taskDescription) {
		for (Task T : tasks) {
			if (T.getTaskID().equals(taskID)) {
				if ((!(taskName.length() > 10)) && (taskName != "")) {
					T.setTaskName(taskName);
				} else {
					if (taskName.length() > 10) {
						System.out.println("Task Name to long");
						return false;	
					} else {
						System.out.println("Task Name is Empty");
						return false;
					}
				}
				if ((!(taskDescription.length() > 50)) && (taskDescription != "")) {
						T.setTaskDescription(taskDescription);
				} else {
					if (taskDescription.length() > 50) {
					System.out.println("Task Description to long");
					return false;
					} else {
						System.out.println("Task Description is empty");
						return false;
					}
				}
				System.out.println("Task Field Successfully Updated");
				return true;
			}
		}
		System.out.println("Task does not exist");
		return false;
	}
}
