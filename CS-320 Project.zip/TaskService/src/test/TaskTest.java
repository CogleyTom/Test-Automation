package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import task.Task;

class TaskTest {

	// Test to create new test to see if it's true
	@Test
	void testTask() {
		Task task = new Task("0001", "Task 1", "This is the first task");
		assertTrue(task.getTaskID().equals("0001"));
		assertTrue(task.getTaskName().equals("Task 1"));
		assertTrue(task.getTaskDescription().equals("This is the first task"));
	}
	
	// Test to see when task ID length over 10 throws exception
	@Test
	void testTaskIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456789123", "Task 1", "This is the first task");
		}); 
	}
	
	// Test to see when task ID is null if exception is thrown
	@Test
	void testTaskIDisNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Task 1", "This is the first task");
		}); 
	}
	
	// Test to see when task name is over 20 exception is thrown
	@Test
	void testTaskNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("0001", "This name should be to long", "This is the first task");
		}); 
	}
	
	// Test to see when task name is null exception is thrown
	@Test
	void testTaskNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("0001", null, "This is the first task");
		}); 
	}
	
	// Test to see when task description is over 50 exception is thrown
	@Test
	void testTaskDescriptionToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("0001", "Task 1", "This Description is to long This Description is to long");
		}); 
	}
	
	// Test to see when task description is null exception is thrown
	@Test
	void testTaskDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("0001", "Task 1", null);
		}); 
	}
}
