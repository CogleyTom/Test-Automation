package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import task.Task;
import task.TaskService;

class TaskServiceTest {

	// Test to see if statements are true or false when adding task service
	@Test
	void addTaskServiceTest() {
		TaskService T = new TaskService();
		Task T1 = new Task("001", "FirstTask", "Testing First Task Service");
		Task T2 = new Task("002", "SecondTask", "Testing Second Task Service");
		Task T3 = new Task("001", "ThirdTask", "Testing Third Task Service");
		Task T4 = new Task("004", "SecondTask", "Testing Fourth Task Service");
		assertEquals(true, T.add(T1));
		assertEquals(true, T.add(T2));
		assertEquals(false, T.add(T3));
		assertEquals(true, T.add(T4));
	}
	
	// Test to see if statements are true or false when deleting task service
	@Test
	void deleteTaskServiceTest() {
		TaskService T = new TaskService();
		Task T1 = new Task("001", "FirstTask", "Testing First Task Service");
		Task T2 = new Task("002", "SecondTask", "Testing Second Task Service");
		assertEquals(true, T.add(T1));
		assertEquals(true, T.add(T2));
		assertEquals(true, T.remove("001"));
		assertEquals(true, T.remove("002"));
		assertEquals(false, T.remove("004"));
	}
	
	// Test to see if statements are true or false when updating task services
	@Test
	void updateTaskServiceTest() {
		TaskService T = new TaskService();
		Task T1 = new Task("001", "FirstTask", "Testing First Task Service");
		Task T2 = new Task("002", "SecondTask", "Testing Second Task Service");
		Task T3 = new Task("003", "ThirdTask", "Testing Third Task Service");
		assertEquals(true, T.add(T1));
		assertEquals(true, T.add(T2));
		assertEquals(true, T.add(T3));
		assertEquals(true, T.update("001", "ThirdTask", "Now it is the third task"));
		assertEquals(true, T.update("002", "FourthTask", "Now this is fourth task"));
		assertEquals(false, T.update("005", "FifthTask", "This is the fifth taks"));
		assertEquals(false, T.update("003", "Third To long", "Now it is the third task"));
		assertEquals(false, T.update("001", "ThirdTask", "Testing if this is to long Testing if this is to long"));
		assertEquals(false, T.update("003", "", "Now it is the third task"));
		assertEquals(false, T.update("001", "ThirdTask", ""));
	}
}
